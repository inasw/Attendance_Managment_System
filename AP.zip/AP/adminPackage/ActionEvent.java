package adminPackage;

public interface ActionEvent {

}
